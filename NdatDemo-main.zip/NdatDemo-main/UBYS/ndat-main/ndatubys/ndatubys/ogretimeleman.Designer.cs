﻿namespace ndatubys
{
    partial class ogretimeleman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ogretimeleman));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.derslerimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nesneyeDayalıAnalizTasarımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nesneyeYönelikProgramlamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yağısalProgramlamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danışmanlıkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.öğrenciListesiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dersKayıtOnayıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.derslerimToolStripMenuItem,
            this.danışmanlıkToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1051, 61);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // derslerimToolStripMenuItem
            // 
            this.derslerimToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nesneyeDayalıAnalizTasarımToolStripMenuItem,
            this.nesneyeYönelikProgramlamaToolStripMenuItem,
            this.yağısalProgramlamaToolStripMenuItem});
            this.derslerimToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("derslerimToolStripMenuItem.Image")));
            this.derslerimToolStripMenuItem.Name = "derslerimToolStripMenuItem";
            this.derslerimToolStripMenuItem.Size = new System.Drawing.Size(89, 57);
            this.derslerimToolStripMenuItem.Text = "Derslerim";
            // 
            // nesneyeDayalıAnalizTasarımToolStripMenuItem
            // 
            this.nesneyeDayalıAnalizTasarımToolStripMenuItem.Name = "nesneyeDayalıAnalizTasarımToolStripMenuItem";
            this.nesneyeDayalıAnalizTasarımToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.nesneyeDayalıAnalizTasarımToolStripMenuItem.Text = "Nesneye Dayalı Analiz ve Tasarım";
            // 
            // nesneyeYönelikProgramlamaToolStripMenuItem
            // 
            this.nesneyeYönelikProgramlamaToolStripMenuItem.Name = "nesneyeYönelikProgramlamaToolStripMenuItem";
            this.nesneyeYönelikProgramlamaToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.nesneyeYönelikProgramlamaToolStripMenuItem.Text = "Nesneye Yönelik Programlama";
            // 
            // yağısalProgramlamaToolStripMenuItem
            // 
            this.yağısalProgramlamaToolStripMenuItem.Name = "yağısalProgramlamaToolStripMenuItem";
            this.yağısalProgramlamaToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
            this.yağısalProgramlamaToolStripMenuItem.Text = "Yapısal Programlama";
            // 
            // danışmanlıkToolStripMenuItem
            // 
            this.danışmanlıkToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.öğrenciListesiToolStripMenuItem,
            this.dersKayıtOnayıToolStripMenuItem});
            this.danışmanlıkToolStripMenuItem.Name = "danışmanlıkToolStripMenuItem";
            this.danışmanlıkToolStripMenuItem.Size = new System.Drawing.Size(84, 57);
            this.danışmanlıkToolStripMenuItem.Text = "Danışmanlık";
            // 
            // öğrenciListesiToolStripMenuItem
            // 
            this.öğrenciListesiToolStripMenuItem.Name = "öğrenciListesiToolStripMenuItem";
            this.öğrenciListesiToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.öğrenciListesiToolStripMenuItem.Text = "Öğrenci Listesi";
            // 
            // dersKayıtOnayıToolStripMenuItem
            // 
            this.dersKayıtOnayıToolStripMenuItem.Name = "dersKayıtOnayıToolStripMenuItem";
            this.dersKayıtOnayıToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.dersKayıtOnayıToolStripMenuItem.Text = "Ders Kayıt Onayı";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.label1.Location = new System.Drawing.Point(209, 102);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(677, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "BLM-3006 - Nesneye Dayalı Analiz ve Tasarım";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Crimson;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(915, 11);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 37);
            this.button1.TabIndex = 7;
            this.button1.Text = "Çıkış Yap";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(38, 209);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(327, 223);
            this.panel1.TabIndex = 8;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(188, 72);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 16;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(188, 105);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 14;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(188, 33);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 11;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(201, 165);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Güncelle";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Final Notu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Vize Notu";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Öğrenci No";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(487, 209);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(538, 223);
            this.dataGridView1.TabIndex = 9;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // ogretimeleman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1051, 669);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ogretimeleman";
            this.Text = "ogretimeleman";
            this.Load += new System.EventHandler(this.ogretimeleman_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem derslerimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danışmanlıkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem öğrenciListesiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dersKayıtOnayıToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem nesneyeDayalıAnalizTasarımToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nesneyeYönelikProgramlamaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yağısalProgramlamaToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}